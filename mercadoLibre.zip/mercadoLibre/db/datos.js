const datos = {
    usuario:{
        email:'ljoaquin@udesa.edu.ar',
        usuario:'jLanusse',
        contrasenia:'hola',
        nacimiento:'23/09/2005',
        dni:'44556677',
        fotoPerfil:'/images/fotoPerfil.jpg',
    },

    productos: [
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbgnW7I-duvxlziaV7asW0JaOUF-_DNBkVmg&s',
            nombre: 'Chevrolet Onix',
            descripcion: 'Auto compacto moderno y eficiente.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSHSdEJadvtDqJSNWKbZiwtRstZXE5JwzgFg&s',
            nombre: 'Toyota Hilux',
            descripcion: 'Camioneta robusta ideal para trabajo pesado.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQksKXx6XFbAcamfGqA5hXYNVtb1Xkr5Ri2mg&s',
            nombre: 'Ford Ranger',
            descripcion: 'Pick-up de gran potencia y tecnología.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWmYeonymIcZMegNpptqkkVvX7y_v8GaJHdg&s',
            nombre: 'Renault Sandero RS',
            descripcion: 'Versión deportiva del hatchback Sandero.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSqXrX-iDk8j7GWmiLbzociG9ZELjdZBe9dA&s',
            nombre: 'Volkswagen Amarok',
            descripcion: 'Camioneta potente y cómoda.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvcp_6cVVi8H-cjguN3g8KH_8DE0MUv1xuMg&s',
            nombre: 'Fiat Cronos',
            descripcion: 'Sedán compacto, el más vendido en Argentina.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYwB4ycF5IY3rH2JshQ8QRLnu9I57iTEs50A&s',
            nombre: 'Peugeot 208',
            descripcion: 'Auto urbano con gran diseño europeo.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWDbgWPepZEX8CDA8mAi2evRRnhQeRKG6tjA&s',
            nombre: 'Honda Civic Type R',
            descripcion: 'Hatchback deportivo de alto rendimiento.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtqdEWLWW8MyBB4lfeCPPmx3DiVhQfXiJVDg&s',
            nombre: 'Kia Sportage',
            descripcion: 'SUV elegante con buen rendimiento.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        },
        {
            imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfcutsJgqhXOMWqUUUVMiXPmVhKyb8uIm4qQ&s',
            nombre: 'Tesla Cybertruck',
            descripcion: 'Camioneta eléctrica futurista.',
            comentarios: [
                {
                    nombreUsuario: 'martina89',
                    comentario: 'Muy económico en ciudad.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/44.jpg'
                },
                {
                    nombreUsuario: 'lucasperez',
                    comentario: 'Buen equipamiento por su precio.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/22.jpg'
                },
                {
                    nombreUsuario: 'agus_fiat',
                    comentario: 'Relación precio/calidad insuperable.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/27.jpg'
                },
                {
                    nombreUsuario: 'jorgeford',
                    comentario: 'Excelente respuesta del motor.',
                    imgPerfil: 'https://randomuser.me/api/portraits/men/46.jpg'
                },
                {
                    nombreUsuario: 'sofiatrucks',
                    comentario: 'Me encanta el diseño.',
                    imgPerfil: 'https://randomuser.me/api/portraits/women/41.jpg'
                }
            ]
        }
    ]
    
}

module.exports = datos